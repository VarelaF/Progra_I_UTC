#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	int MaximoPersonas=3;
	int CantPersonasRegist=0;
	char nombrePersona[20]="";
	char Persona1[20]="";;
	char Persona2[20]="";;
	char Persona3[20]="";;
	int LugarReciclaje=0;
	char Hogar[]="Hogar";
	char CenEducativo[]="Centro Educativo";
	char CenSalud[]="Centro de Salud";
	char Empresas[]="Empresa";
	
	int CategoriaMaterial=0;
	
	int CantidadHogares=0;
	int CantidadCenEduc=0;
	int CantidadCenSalud=0;
	int CantidadEmpresas=0;
	
	int plasticosLatas=0;
	int papelCarton=0;
	int vidrio=0;
	int organicos=0;
	int NoReciclable=0;
	
	int PagoPalstLatas=0;
	int PagoPapelCart=0;
	int PagoVidrio=0;
	int PagoOrganico=0;
	int PagoNoRecliclable=0;
	
	
		
	do
	{
	int opcion=0;
		system("cls");
		printf("\n\t\t	====================================================");
		printf("\n \t\t\t|\tSISTEMA DE TRATAMIENTO DE RESIDUOS\t   |\n");
		printf("\n \t\t\t|\t\t'EL PLANETA FELIZ' \t\t   |\n");
		printf("\t\t	====================================================\n\n\n\n");
		printf("\n\t << Lugares de reciclaje >>\n");
		printf("\n\t1: Hogar");	
		printf("\n\t2: Centro Educativo");
		printf("\n\t3: Centro de Salud");
		printf("\n\t4: Empresas");
		printf("\n\n\tPor favor digite una opci�n seg�n su lugar de reciclaje: ");
		printf(">> ");
		scanf("%i",&opcion);fflush(stdin);
		printf("\n\n\tPor favor digite su nombre: ");
		printf(">> ");
		scanf("%s",&nombrePersona);
		printf("\n\n\t<< Categoria de reciclaje segun materiales b�sicos >>");
		printf("\n\n\t1: Pl�sticos, latas y bricks");	
		printf("\t2: Papel y cart�n.");
		printf("\t3: Vidrio");
		printf("\n\t4: Org�nicos");
		printf("\t\t\t5: No reciclables");
		printf("\n\n\tSegun la categoria de su material, escoja una opci�n ");
		printf(">> ");
		scanf("%i",&CategoriaMaterial);fflush(stdin);
		
		if(CantPersonasRegist==0)
		{
		strcpy(Persona1,nombrePersona);
		}
		if(CantPersonasRegist==1)
		{
		strcpy(Persona2,nombrePersona);
		}
		if(CantPersonasRegist==2)
		{
		strcpy(Persona3,nombrePersona);
		}
			if(opcion == 1)
			{
				CantidadHogares++;			
			}
			if(opcion == 2)
			{			
				CantidadCenEduc++;	
			}
			if(opcion == 3)
			{			
				CantidadCenSalud++;	
			}
			if(opcion == 4)
			{			
				CantidadEmpresas++;
			}
			if(CategoriaMaterial == 1)// categorias
			{
				plasticosLatas++;	
				PagoPalstLatas+=2;		
			}
				if(CategoriaMaterial == 2)
			{
				papelCarton++;	
				PagoPapelCart+=3;		
			}
				if(CategoriaMaterial == 3)
			{
				vidrio++;
				PagoVidrio+=4;			
			}
				if(CategoriaMaterial == 4)
			{
				organicos++;	
				PagoOrganico+=5;		
			}
				if(CategoriaMaterial == 5)
			{
				NoReciclable++;	
				PagoNoRecliclable+=6;		
			}
			
		CantPersonasRegist++;
	}while((CantPersonasRegist<3));
	
	system("cls");
	printf("\n\t\t	====================================================");
	printf("\n \t\t\t|\tSISTEMA DE TRATAMIENTO DE RESIDUOS\t   |\n");
	printf("\n \t\t\t|\t\t'EL PLANETA FELIZ' \t\t   |\n");
	printf("\t\t	====================================================\n\n\n\n");	
	printf("\tEstadisticas de ingreso para reciclaje:\n ");	
	printf("\t--------------------------------------------\n");
	printf("\tPersonas Registradas: ");
	printf("- %s",Persona1);
	printf("\t- %s",Persona2);
	printf("\t- %s",Persona3);
	printf("\n\n\t Total de Personas:");
	printf(" %i",CantPersonasRegist);
	printf("\n\n\t Total de Hogares: ");
	printf("%i",CantidadHogares);
	printf("\t Total de Centro Educativo: ");
	printf("%i",CantidadCenEduc);
	printf("\t Total de Centro de Salud: ");
	printf("%i",CantidadCenSalud);
	printf("\t Total de Empresas: ");
	printf("%i",CantidadEmpresas);
	printf("\n\n\t xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
	printf("\n\t Total de las categorias a reciclar: ");// total de categorias
	printf("\n\n\t Plasticos-latas-bricks: ");// total de plasticos
	printf("%i",plasticosLatas);
	printf("\n\t Papel-carton: ");// total de papel-cartin
	printf("%i",papelCarton);
	printf("\n\t Vidrio: ");// total de vidrio
	printf("%i",vidrio);
	printf("\n\t Organicos: ");// total de organios
	printf("%i",organicos);
	printf("\n\t No reciclable: ");// total de reciclable
	printf("%i",NoReciclable);
	printf("\n\t xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
	printf("\n\t $$ Tabla de pagos segun la categoria a reciclar: $$");// tabla de pagos segun su categoria
	printf("\n\n\t ($2 c/u) Plasticos-latas-bricks: $");//
	printf("%i",PagoPalstLatas);
	printf("\n\t ($3 c/u) Papel-carton: $");// 
	printf("%i",PagoPapelCart);
	printf("\n\t ($4 c/u) Vidrio: $");// 
	printf("%i",PagoVidrio);
	printf("\n\t ($5 c/u) Organicos: $");// 
	printf("%i",PagoOrganico);
	printf("\n\t ($6 c/u) No reciclable: $");
	printf("%i",PagoNoRecliclable);
		
	/*
		Falta el total de materiales a reciclar por categoria ejem: plasticos: 2 - carton: 1 - vidrio 3
		Falta la cantidad de dolares a dar por el intercambio de la basura ejm:
		plasticos: $2 - carton $3 - vidrio $4
		Hacer la sumatoria del total de dolares distribuidos los lugares: total de $ para hogares: $12 - total de $ para Empresas: $12
	*/
		printf("\n\n");
	return 0;
}
